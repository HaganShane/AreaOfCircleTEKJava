package com.hagan.areacalculator;

public class AreaOfACircle {
	
	/*
	 * Declare our global instance variables
	 */
	static double area = 0;
	static double radius = 5;
	static double pi = 3.14;
	
	public static void main(String[] args) {
		/*
		 * Call our two methods in the main method to execute
		 */
		calcAreaOfCircle(radius, pi);
		displayArea(area);
	}
	
	/*
	 * calcAreaOfCircle to calculate the area using our formula
	 * Takes in 2 arguments: r (radius) and p (pi)
	 */
	public static void calcAreaOfCircle(double r, double p) {
		area = p * (r * r);
	}

	/*
	 * displayArea to display our area using println
	 * Takes in 1 argument: a (area)
	 */
	public static void displayArea(double a) {
		System.out.println(a);
	}
}

/*
 * Tested with radius of 5, area was 78.5
 * Tested with radius of 7, area was 153.86 
 * Tested with radius of 10, area was 314.0
*/